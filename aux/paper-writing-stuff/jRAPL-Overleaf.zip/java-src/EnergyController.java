
package jRAPL;

public class EnergyController extends EnergyManager {

	// This hasn't been implemented at all. Will be a way to control energy activity, with
	// DVFS or with MSR RAPL powercapping. Most of that will be done in is subclasses,
	// PowercapEnergyController and DvfsEnergyController

}
